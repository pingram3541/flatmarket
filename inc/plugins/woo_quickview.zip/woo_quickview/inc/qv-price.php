<?php global $post, $product, $woocommerce; ?>

<?php echo '<p class="price">'. $product->get_price_html() .'</p>'; ?>